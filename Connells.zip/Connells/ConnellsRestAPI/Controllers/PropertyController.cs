﻿using ConnellsRestAPI.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace ConnellsRestAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PropertyController : ControllerBase
    {
        private readonly IPropertyRepository _context;

        public PropertyController(IPropertyRepository context)
        {
            _context = context;
        }

        [HttpPost]
        public Task<IActionResult> SaveProperties()
        {
            _context.SaveProperty();

            //return Ok("this is saved");
        }
    }
}
