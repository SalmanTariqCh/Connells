﻿using ConnellsRestAPI.Models;

namespace ConnellsRestAPI.Repositories
{
    public class PropertyRepository : IPropertyRepository
    {
        public List<Property> _properties;
        public PropertyRepository() 
        {
            _properties = new List<Property>()
            {
                new Property
                {
                    Id = 1,
                    Name = "Property A",
                    Address = "Milton Keynes",
                    Price = 150
                },
                new Property
                {
                    Id = 2,
                    Name = "Property B",
                    Address = "Bedford",
                    Price = 170
                }
            };
        }

        public Task AddPropertyAsync(Property property)
        {
            if (_properties.Any(x => x.Name.Equals(property.Name, StringComparison.OrdinalIgnoreCase)))
            {
                return Task.CompletedTask;
            }

            var maxId = _properties.Max(x => x.Id);

            property.Id = maxId + 1;
            _properties.Add(property);

            return Task.CompletedTask;
        }

        public async Task SaveProperty()
        {
            throw new NotImplementedException();
        }
    }
}
