﻿using ConnellsRestAPI.Models;

namespace ConnellsRestAPI.Repositories
{
    public interface IPropertyRepository
    {
        Task SaveProperty();
        Task AddPropertyAsync(Property property);
    }
}
