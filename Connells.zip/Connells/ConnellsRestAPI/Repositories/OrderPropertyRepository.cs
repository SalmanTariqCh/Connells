﻿using ConnellsRestAPI.Models;

namespace ConnellsRestAPI.Repositories
{
    public class OrderPropertyRepository : IOrderPropertyRepository
    {
        public List<PropertyOrder> _orderProperties;

        public OrderPropertyRepository()
        {
            _orderProperties = new List<PropertyOrder>()
            {
                new PropertyOrder
                {
                    Id = 1,
                    PageSize = 7,
                    PageNo = 8,
                    Order = "Order A"
                },
                new PropertyOrder
                {
                    Id = 2,
                    PageSize = 10,
                    PageNo = 9,
                    Order = "Order B"
                }
            };
        }
        public async Task<List<PropertyOrder>> GetAllPropertyOrder()
        {
            var sortedProperties = _orderProperties.OrderBy(item => item.Id).ToList();

            return await Task.FromResult(sortedProperties);
        }


        public Task<PropertyOrder> GetPropertyOrder(int id)
        {
            throw new NotImplementedException();
        }
    }
}
