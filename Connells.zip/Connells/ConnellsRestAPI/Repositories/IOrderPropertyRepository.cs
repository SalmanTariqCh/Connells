﻿using ConnellsRestAPI.Models;

namespace ConnellsRestAPI.Repositories
{
    public interface IOrderPropertyRepository
    {
        Task<List<PropertyOrder>> GetAllPropertyOrder();
        Task<PropertyOrder> GetPropertyOrder(int id);

    }
}
