﻿using System.ComponentModel.DataAnnotations;

namespace ConnellsRestAPI.Models
{
    public class Property
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        [Required(ErrorMessage = "Address is required.")]
        [StringLength(50, ErrorMessage = "Address must be at most 100 characters long.")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Price is required.")]
        [RegularExpression(@"^\d+$", ErrorMessage = "Price must be a whole number.")]
        public decimal Price { get; set; }
    }
}
