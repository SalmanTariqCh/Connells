﻿namespace ConnellsRestAPI.Models
{
    public class Order
    {
    }
}
