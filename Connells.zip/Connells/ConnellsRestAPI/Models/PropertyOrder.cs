﻿using System.ComponentModel.DataAnnotations;

namespace ConnellsRestAPI.Models
{
    public class PropertyOrder
    {
        public int Id { get; set; }

        private int _pageSize = 10;
        private int _pageNo = 1;

        [Range(5, 20, ErrorMessage = "Page Size must be between 5 and 20.")]
        public int PageSize
        {
            get { return _pageSize; }
            set { _pageSize = value; }
        }

        public int PageNo
        {
            get { return _pageNo; }
            set { _pageNo = value; }
        }

        public string Order { get; set; }
        //public DateTime OrderDate { get; set; }
    }
}
